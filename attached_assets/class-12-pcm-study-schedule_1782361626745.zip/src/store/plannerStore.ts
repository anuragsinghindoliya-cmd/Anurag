// ═══════════════════════════════════════════════════════════
// PLANNER STORE — localStorage-backed state management
// ═══════════════════════════════════════════════════════════

import { useState, useCallback } from 'react';
import { SUBJECTS, generateSchedule, type SubjectKey } from '../data/plannerData';

// ── Types ──────────────────────────────────────────────────

export interface ChapterStatus {
  chapterId: string;
  subject: SubjectKey;
  lecturesWatched: number;
  totalLectures: number; // editable
  completed: boolean;
  testsDone: TestRecord[];
  notes: string;
  startedAt?: string;
  completedAt?: string;
}

export interface TestRecord {
  id: string;
  date: string;
  score: number;
  maxScore: number;
  type: 'chapter' | 'unit' | 'mock' | 'practice';
  notes: string;
}

export interface DayTaskStatus {
  date: string;
  blockId: string;
  status: 'pending' | 'done' | 'not-done' | 'partial';
  lecturesDone: number;
  extraLectures: number;
  notes: string;
}

export interface PlannerState {
  chapters: Record<string, ChapterStatus>;
  tasks: Record<string, DayTaskStatus>;
  streak: number;
  lastStudyDate: string;
}

const STORAGE_KEY = 'anurag_planner_v2';

function getDefaultState(): PlannerState {
  const chapters: Record<string, ChapterStatus> = {};

  SUBJECTS.forEach(subject => {
    subject.chapters.forEach(chapter => {
      chapters[chapter.id] = {
        chapterId: chapter.id,
        subject: subject.key,
        lecturesWatched: 0,
        totalLectures: chapter.lectures,
        completed: false,
        testsDone: [],
        notes: '',
      };
    });
  });

  return {
    chapters,
    tasks: {},
    streak: 0,
    lastStudyDate: '',
  };
}

function loadState(): PlannerState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultState();
    const parsed = JSON.parse(raw) as PlannerState;
    // Merge any missing chapters from default
    const def = getDefaultState();
    Object.keys(def.chapters).forEach(id => {
      if (!parsed.chapters[id]) {
        parsed.chapters[id] = def.chapters[id];
      }
    });
    return parsed;
  } catch {
    return getDefaultState();
  }
}

function saveState(state: PlannerState): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

// ── Hook ───────────────────────────────────────────────────

export function usePlannerStore() {
  const [state, setStateRaw] = useState<PlannerState>(loadState);

  const setState = useCallback((updater: (prev: PlannerState) => PlannerState) => {
    setStateRaw(prev => {
      const next = updater(prev);
      saveState(next);
      return next;
    });
  }, []);

  // Derived: per-subject progress
  const getSubjectProgress = useCallback((subjectKey: SubjectKey) => {
    const subjectChapters = Object.values(state.chapters).filter(c => c.subject === subjectKey);
    const totalLectures   = subjectChapters.reduce((s, c) => s + c.totalLectures, 0);
    const doneLectures    = subjectChapters.reduce((s, c) => s + Math.min(c.lecturesWatched, c.totalLectures), 0);
    const totalChapters   = subjectChapters.length;
    const doneChapters    = subjectChapters.filter(c => c.completed).length;
    const pct = totalLectures > 0 ? Math.round((doneLectures / totalLectures) * 100) : 0;
    return { totalLectures, doneLectures, totalChapters, doneChapters, pct };
  }, [state.chapters]);

  const getOverallProgress = useCallback(() => {
    const all = Object.values(state.chapters);
    const total = all.reduce((s, c) => s + c.totalLectures, 0);
    const done  = all.reduce((s, c) => s + Math.min(c.lecturesWatched, c.totalLectures), 0);
    const totalCh = all.length;
    const doneCh  = all.filter(c => c.completed).length;
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    return { total, done, totalCh, doneCh, pct };
  }, [state.chapters]);

  // ── Chapter actions ──────────────────────────────────────

  const updateLectures = useCallback((chapterId: string, watched: number) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.lecturesWatched = Math.max(0, watched);
      ch.completed = ch.lecturesWatched >= ch.totalLectures;
      if (ch.completed && !ch.completedAt) ch.completedAt = new Date().toISOString();
      if (!ch.startedAt && ch.lecturesWatched > 0) ch.startedAt = new Date().toISOString();
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const updateTotalLectures = useCallback((chapterId: string, total: number) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.totalLectures = Math.max(1, total);
      ch.completed = ch.lecturesWatched >= ch.totalLectures;
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const toggleChapterComplete = useCallback((chapterId: string) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.completed = !ch.completed;
      if (ch.completed) {
        ch.lecturesWatched = ch.totalLectures;
        ch.completedAt = new Date().toISOString();
      } else {
        ch.completedAt = undefined;
      }
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const addTest = useCallback((chapterId: string, test: Omit<TestRecord, 'id'>) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.testsDone = [...ch.testsDone, { ...test, id: `test-${Date.now()}` }];
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const updateTest = useCallback((chapterId: string, testId: string, updates: Partial<TestRecord>) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.testsDone = ch.testsDone.map(t => t.id === testId ? { ...t, ...updates } : t);
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const deleteTest = useCallback((chapterId: string, testId: string) => {
    setState(prev => {
      const ch = { ...prev.chapters[chapterId] };
      ch.testsDone = ch.testsDone.filter(t => t.id !== testId);
      return { ...prev, chapters: { ...prev.chapters, [chapterId]: ch } };
    });
  }, [setState]);

  const updateChapterNotes = useCallback((chapterId: string, notes: string) => {
    setState(prev => ({
      ...prev,
      chapters: {
        ...prev.chapters,
        [chapterId]: { ...prev.chapters[chapterId], notes },
      },
    }));
  }, [setState]);

  // ── Day Task actions ─────────────────────────────────────

  const updateTask = useCallback((blockId: string, date: string, updates: Partial<DayTaskStatus>) => {
    setState(prev => {
      const key = `${date}-${blockId}`;
      const existing = prev.tasks[key] || { date, blockId, status: 'pending', lecturesDone: 0, extraLectures: 0, notes: '' };
      const updated = { ...existing, ...updates };

      // Update streak
      let { streak, lastStudyDate } = prev;
      if (updates.status === 'done') {
        const today = date;
        if (lastStudyDate !== today) {
          const last = lastStudyDate ? new Date(lastStudyDate) : null;
          const curr = new Date(today);
          if (last) {
            const diff = Math.round((curr.getTime() - last.getTime()) / 86400000);
            streak = diff === 1 ? streak + 1 : 1;
          } else {
            streak = 1;
          }
          lastStudyDate = today;
        }
      }

      return {
        ...prev,
        tasks: { ...prev.tasks, [key]: updated },
        streak,
        lastStudyDate,
      };
    });
  }, [setState]);

  const getTask = useCallback((blockId: string, date: string): DayTaskStatus => {
    const key = `${date}-${blockId}`;
    return state.tasks[key] || { date, blockId, status: 'pending', lecturesDone: 0, extraLectures: 0, notes: '' };
  }, [state.tasks]);

  // ── Schedule ─────────────────────────────────────────────
  const schedule = generateSchedule();

  const getDaySchedule = useCallback((dateStr: string) => {
    return schedule.find(d => d.date === dateStr);
  }, [schedule]);

  const getWeekSchedule = useCallback((weekNum: number) => {
    return schedule.filter(d => d.week === weekNum);
  }, [schedule]);

  // Reset all data
  const resetAll = useCallback(() => {
    const fresh = getDefaultState();
    saveState(fresh);
    setStateRaw(fresh);
  }, []);

  return {
    state,
    schedule,
    getSubjectProgress,
    getOverallProgress,
    updateLectures,
    updateTotalLectures,
    toggleChapterComplete,
    addTest,
    updateTest,
    deleteTest,
    updateChapterNotes,
    updateTask,
    getTask,
    getDaySchedule,
    getWeekSchedule,
    resetAll,
  };
}
