import { useState, useEffect } from 'react';
import { usePlannerStore } from './store/plannerStore';
import Dashboard from './components/Dashboard';
import Timetable from './components/Timetable';
import ChapterTracker from './components/ChapterTracker';
import Analytics from './components/Analytics';
import PacingGuide from './components/PacingGuide';
import Settings from './components/Settings';

type Tab = 'dashboard' | 'timetable' | 'chapters' | 'analytics' | 'pacing' | 'settings';

const TABS: { id: Tab; icon: string; label: string }[] = [
  { id: 'dashboard',  icon: '🏠', label: 'Dashboard'    },
  { id: 'timetable',  icon: '📅', label: 'Timetable'    },
  { id: 'chapters',   icon: '📚', label: 'Chapters'     },
  { id: 'analytics',  icon: '📊', label: 'Analytics'    },
  { id: 'pacing',     icon: '🗓️', label: 'Pacing Guide' },
  { id: 'settings',   icon: '⚙️', label: 'Settings'     },
];

export default function App() {
  const store = usePlannerStore();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const overall = store.getOverallProgress();

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg-void)' }}>
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl float"
            style={{ background: 'linear-gradient(145deg, #6c63ff, #00d4ff)' }}>
            🎯
          </div>
          <div className="text-white font-bold text-lg">Loading Command Center...</div>
          <div className="progress-3d w-48" style={{ height: 4 }}>
            <div className="progress-fill" style={{
              width: '60%',
              background: 'linear-gradient(90deg, #6c63ff, #00d4ff)',
              animation: 'shimmer 1.5s infinite',
            }} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen star-grid" style={{ background: 'var(--bg-void)' }}>

      {/* ── Top Navigation Bar ── */}
      <header className="fixed top-0 left-0 right-0 z-40"
        style={{
          background: 'rgba(10,13,26,0.92)',
          backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255,255,255,0.07)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.5)',
        }}>
        <div className="max-w-screen-2xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg font-black"
              style={{
                background: 'linear-gradient(145deg, #6c63ff, #00d4ff)',
                boxShadow: '0 3px 0 #3a2fd4, 0 4px 15px rgba(108,99,255,0.4)',
              }}>
              A
            </div>
            <div className="hidden sm:block">
              <div className="text-sm font-black text-white leading-none">Anurag's</div>
              <div className="text-xs leading-none" style={{ color: '#6c63ff' }}>Academic Planner</div>
            </div>
          </div>

          {/* Desktop Tabs */}
          <nav className="hidden lg:flex items-center gap-1">
            {TABS.map(tab => (
              <button key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>

          {/* Right: Progress + Streak */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="hidden md:flex items-center gap-2">
              <div className="w-24 progress-3d" style={{ height: 6 }}>
                <div className="progress-fill" style={{
                  width: `${overall.pct}%`,
                  background: 'linear-gradient(90deg, #6c63ff, #00d4ff)',
                  boxShadow: '0 0 8px rgba(108,99,255,0.5)',
                }} />
              </div>
              <span className="text-xs font-bold" style={{ color: '#6c63ff' }}>{overall.pct}%</span>
            </div>
            <div className="flex items-center gap-1.5 card-extruded px-3 py-1.5">
              <span className="text-base">🔥</span>
              <span className="text-sm font-black text-white">{store.state.streak}</span>
            </div>
            {/* Mobile hamburger */}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden btn-3d btn-ghost w-9 h-9 p-0 text-lg rounded-xl">
              {sidebarOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>
      </header>

      {/* ── Mobile Sidebar ── */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}>
          <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }} />
          <nav className="absolute top-14 left-0 bottom-0 w-64 p-4 space-y-2"
            style={{
              background: 'var(--bg-surface)',
              borderRight: '1px solid rgba(255,255,255,0.07)',
              boxShadow: '4px 0 20px rgba(0,0,0,0.5)',
            }}
            onClick={e => e.stopPropagation()}>
            <div className="text-xs font-bold uppercase tracking-widest mb-3 px-2"
              style={{ color: 'rgba(255,255,255,0.3)' }}>Navigation</div>
            {TABS.map(tab => (
              <button key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                className={`nav-tab w-full justify-start ${activeTab === tab.id ? 'active' : ''}`}>
                <span className="text-xl">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
            <div className="divider-glow my-4" />
            <div className="px-2 space-y-1">
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>Overall Progress</div>
              <div className="progress-3d">
                <div className="progress-fill" style={{
                  width: `${overall.pct}%`,
                  background: 'linear-gradient(90deg, #6c63ff, #00d4ff)',
                }} />
              </div>
              <div className="text-xs font-bold" style={{ color: '#6c63ff' }}>{overall.pct}% Complete</div>
            </div>
          </nav>
        </div>
      )}

      {/* ── Main Content ── */}
      <main className="pt-14 min-h-screen">
        <div className="max-w-screen-2xl mx-auto">
          {activeTab === 'dashboard' && <Dashboard store={store} />}
          {activeTab === 'timetable' && <Timetable store={store} />}
          {activeTab === 'chapters' && <ChapterTracker store={store} />}
          {activeTab === 'analytics' && <Analytics store={store} />}
          {activeTab === 'pacing' && <PacingGuide store={store} />}
          {activeTab === 'settings' && <Settings store={store} />}
        </div>
      </main>

      {/* ── Bottom Nav (Mobile) ── */}
      <div className="fixed bottom-0 left-0 right-0 lg:hidden z-40"
        style={{
          background: 'rgba(10,13,26,0.95)',
          backdropFilter: 'blur(20px)',
          borderTop: '1px solid rgba(255,255,255,0.07)',
          boxShadow: '0 -4px 20px rgba(0,0,0,0.5)',
        }}>
        <div className="flex">
          {TABS.map(tab => (
            <button key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 flex flex-col items-center justify-center py-2 gap-0.5"
              style={{
                color: activeTab === tab.id ? '#6c63ff' : 'rgba(255,255,255,0.35)',
                fontSize: '0.65rem',
                fontWeight: activeTab === tab.id ? 700 : 500,
                transition: 'color 0.2s ease',
              }}>
              <span className="text-xl leading-none">{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom padding for mobile nav */}
      <div className="h-16 lg:hidden" />

      {/* Ambient Background Blobs */}
      <div className="fixed pointer-events-none inset-0 -z-10 overflow-hidden">
        <div style={{
          position: 'absolute', top: '-20%', left: '-10%',
          width: 600, height: 600, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(108,99,255,0.06) 0%, transparent 70%)',
        }} />
        <div style={{
          position: 'absolute', bottom: '-20%', right: '-10%',
          width: 600, height: 600, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,212,255,0.05) 0%, transparent 70%)',
        }} />
        <div style={{
          position: 'absolute', top: '40%', right: '20%',
          width: 400, height: 400, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,229,160,0.04) 0%, transparent 70%)',
        }} />
      </div>
    </div>
  );
}
