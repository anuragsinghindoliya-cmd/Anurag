import { useState } from 'react';
import { SUBJECTS } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';

type Store = ReturnType<typeof usePlannerStore>;
interface Props { store: Store; }

export default function Settings({ store }: Props) {
  const [confirmReset, setConfirmReset] = useState(false);

  const handleExport = () => {
    const data = JSON.stringify(store.state, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `anurag-planner-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        localStorage.setItem('anurag_planner_v2', JSON.stringify(data));
        window.location.reload();
      } catch {
        alert('Invalid backup file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-5 p-4 md:p-6 anim-fade-scale">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">⚙️ Settings & Profile</h1>
        <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
          Manage your planner data, backup, and preferences
        </p>
      </div>

      {/* Profile Card */}
      <div className="card-3d p-6 relative overflow-hidden shimmer">
        <div className="absolute inset-0 star-grid opacity-20 pointer-events-none" />
        <div className="relative flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl font-black"
            style={{
              background: 'linear-gradient(145deg, #6c63ff, #00d4ff)',
              boxShadow: '0 4px 0 #3a2fd4, 0 8px 30px rgba(108,99,255,0.4)',
            }}>
            A
          </div>
          <div>
            <h2 className="text-xl font-black text-white">Anurag Singh Indoliya</h2>
            <div className="text-sm mt-0.5" style={{ color: 'rgba(255,255,255,0.5)' }}>Class 12 PCM Student</div>
            <div className="flex gap-3 mt-2 flex-wrap">
              <span className="badge-3d" style={{ color: '#6c63ff', borderColor: '#6c63ff' }}>Physics</span>
              <span className="badge-3d" style={{ color: '#00e5a0', borderColor: '#00e5a0' }}>Chemistry</span>
              <span className="badge-3d" style={{ color: '#00d4ff', borderColor: '#00d4ff' }}>Math</span>
              <span className="badge-3d" style={{ color: '#ffb347', borderColor: '#ffb347' }}>English</span>
              <span className="badge-3d" style={{ color: '#ff6b9d', borderColor: '#ff6b9d' }}>Hindi</span>
            </div>
          </div>
        </div>
        <div className="relative mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Plan Start', value: '21 Jul 2025' },
            { label: 'Target Date', value: '7 Dec 2025' },
            { label: 'Total Weeks', value: '24 Weeks' },
            { label: 'Study Streak', value: `${store.state.streak} Days 🔥` },
          ].map((item, i) => (
            <div key={i} className="card-extruded px-3 py-2 text-center">
              <div className="text-sm font-bold text-white">{item.value}</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{item.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Lecture Count Editor */}
      <div className="card-3d p-5">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
          🎛️ Edit Lecture Counts (All Chapters)
        </h3>
        <p className="text-sm mb-4" style={{ color: 'rgba(255,255,255,0.45)' }}>
          Click the lecture count next to any chapter in the Chapter Tracker to edit it inline. Changes are saved immediately.
        </p>
        <div className="space-y-4">
          {SUBJECTS.map(subj => {
            const p = store.getSubjectProgress(subj.key);
            return (
              <div key={subj.key} className="card-extruded p-4">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xl">{subj.icon}</span>
                  <span className="font-bold text-white">{subj.label}</span>
                  <span className="ml-auto text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    Total: {p.totalLectures} lectures
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {subj.chapters.map(ch => {
                    const status = store.state.chapters[ch.id];
                    return (
                      <div key={ch.id} className="flex items-center gap-2 py-1.5 px-2 rounded-lg"
                        style={{ background: 'rgba(255,255,255,0.03)' }}>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs text-white truncate">{ch.name}</div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button onClick={() => store.updateTotalLectures(ch.id, Math.max(1, (status?.totalLectures || ch.lectures) - 1))}
                            className="btn-3d btn-ghost w-5 h-5 p-0 text-xs rounded">−</button>
                          <span className="w-6 text-center text-xs font-bold" style={{ color: subj.color }}>
                            {status?.totalLectures || ch.lectures}
                          </span>
                          <button onClick={() => store.updateTotalLectures(ch.id, (status?.totalLectures || ch.lectures) + 1)}
                            className="btn-3d btn-ghost w-5 h-5 p-0 text-xs rounded">+</button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Data Management */}
      <div className="card-3d p-5">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
          💾 Data Management
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button onClick={handleExport} className="btn-3d btn-primary py-3 flex-col gap-1 h-auto">
            <span className="text-xl">📤</span>
            <span className="text-sm font-bold">Export Backup</span>
            <span className="text-xs opacity-60">Download JSON</span>
          </button>
          <label className="btn-3d btn-ghost py-3 flex flex-col items-center gap-1 h-auto cursor-pointer">
            <span className="text-xl">📥</span>
            <span className="text-sm font-bold">Import Backup</span>
            <span className="text-xs opacity-60">Restore JSON</span>
            <input type="file" accept=".json" className="hidden" onChange={handleImport} />
          </label>
          <button
            onClick={() => setConfirmReset(true)}
            className="btn-3d btn-danger py-3 flex-col gap-1 h-auto">
            <span className="text-xl">🗑️</span>
            <span className="text-sm font-bold">Reset All Data</span>
            <span className="text-xs opacity-60">Cannot be undone</span>
          </button>
        </div>
        {confirmReset && (
          <div className="mt-4 p-4 rounded-xl" style={{ background: 'rgba(255,77,109,0.1)', border: '1px solid rgba(255,77,109,0.3)' }}>
            <p className="text-sm text-white font-semibold mb-3">⚠️ Are you sure? This will delete all your progress, test records, and task status.</p>
            <div className="flex gap-3">
              <button onClick={() => { store.resetAll(); setConfirmReset(false); }}
                className="btn-3d btn-danger px-5 py-2 text-sm">Yes, Reset Everything</button>
              <button onClick={() => setConfirmReset(false)}
                className="btn-3d btn-ghost px-5 py-2 text-sm">Cancel</button>
            </div>
          </div>
        )}
      </div>

      {/* Focus Mode Reminder */}
      <div className="card-3d p-5" style={{ borderLeft: '3px solid #6c63ff' }}>
        <h3 className="font-bold text-white mb-3 flex items-center gap-2">
          <span>📵</span> Samsung Galaxy Tab A9 — Focus Mode Setup
        </h3>
        <div className="space-y-2 text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
          <div className="flex gap-2">
            <span>1️⃣</span>
            <span>Go to <b className="text-white">Settings → Digital Wellbeing & Parental Controls</b></span>
          </div>
          <div className="flex gap-2">
            <span>2️⃣</span>
            <span>Tap <b className="text-white">Focus Mode</b> → Select all non-academic apps to block</span>
          </div>
          <div className="flex gap-2">
            <span>3️⃣</span>
            <span>Set schedule: <b className="text-white">6:00–8:00 AM</b> and <b className="text-white">12:00–2:00 PM</b> daily (Mon–Sat)</span>
          </div>
          <div className="flex gap-2">
            <span>4️⃣</span>
            <span>Apps to block: YouTube, Instagram, Games, WhatsApp (personal)</span>
          </div>
          <div className="flex gap-2">
            <span>5️⃣</span>
            <span>Allow: <b className="text-white">PhysicsWallah / YouTube (study) / This Planner App</b></span>
          </div>
        </div>
      </div>

      {/* Study Rules Quick Ref */}
      <div className="card-3d p-5">
        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
          <span>📋</span> Quick Reference — Study Rules
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {[
            {
              title: '🌅 Morning Block 1', color: '#00d4ff',
              rules: ['6:00 AM – 8:00 AM', 'Tab A9 Focus Mode ON', 'Day A: Physics | Day B: Math', 'Phase 2: 2 lectures for Phy & Math', 'Mon–Thu: 15-20 min review first']
            },
            {
              title: '☀️ Midday Block 2', color: '#00e5a0',
              rules: ['12:00 PM onward', 'Tab A9 Focus Mode ON', 'Day A: Chemistry | Day B: English/Hindi', 'Chemistry always 1 lecture', 'Language: 45 minutes max']
            },
            {
              title: '⏸️ Between Blocks', color: '#ffb347',
              rules: ['3–4 hour gap strictly', 'Screen-FREE recharge', 'Light exercise / walk', 'No social media', 'Power nap if needed']
            },
            {
              title: '📅 Weekly Structure', color: '#ff6b9d',
              rules: ['Mon–Thu: Full execution', 'Friday (Ph2): Hybrid Day — Phy/Chem spaced recall', 'Saturday (Ph2): Hybrid — Math/Lang blank-sheet', 'Sunday: ZERO STUDY — rest completely']
            },
          ].map(section => (
            <div key={section.title} className="card-extruded p-4"
              style={{ borderLeft: `3px solid ${section.color}` }}>
              <h4 className="font-bold mb-2" style={{ color: section.color }}>{section.title}</h4>
              <ul className="space-y-1">
                {section.rules.map((rule, i) => (
                  <li key={i} className="flex gap-2" style={{ color: 'rgba(255,255,255,0.55)' }}>
                    <span style={{ color: section.color }}>›</span> {rule}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
