import { useMemo } from 'react';
import { SUBJECTS } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  PieChart, Pie, Cell, ResponsiveContainer,
  LineChart, Line, Area, AreaChart,
} from 'recharts';

type Store = ReturnType<typeof usePlannerStore>;
interface Props { store: Store; }

const RADIAN = Math.PI / 180;
const CustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
  if (percent < 0.06) return null;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.6;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central"
      style={{ fontSize: 11, fontWeight: 700, fontFamily: 'Inter' }}>
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const tooltipStyle = {
  background: '#141829',
  border: '1px solid rgba(255,255,255,0.1)',
  borderRadius: 10,
  color: '#fff',
  fontSize: 12,
};

export default function Analytics({ store }: Props) {
  // Subject completion data
  const subjectData = useMemo(() =>
    SUBJECTS.map(s => {
      const p = store.getSubjectProgress(s.key);
      return {
        name: s.label,
        icon: s.icon,
        color: s.color,
        done: p.doneLectures,
        remaining: p.totalLectures - p.doneLectures,
        pct: p.pct,
        chapters: p.doneChapters,
        totalChapters: p.totalChapters,
      };
    }),
  [store]);

  // All tests for performance chart
  const allTests = useMemo(() => {
    const tests: Array<{ date: string; subject: string; pct: number; type: string; color: string }> = [];
    SUBJECTS.forEach(s => {
      s.chapters.forEach(ch => {
        const status = store.state.chapters[ch.id];
        if (status) {
          status.testsDone.forEach(t => {
            tests.push({
              date: t.date,
              subject: s.label,
              pct: Math.round((t.score / t.maxScore) * 100),
              type: t.type,
              color: s.color,
            });
          });
        }
      });
    });
    return tests.sort((a, b) => a.date.localeCompare(b.date));
  }, [store.state.chapters]);

  // Lecture progress over weeks
  const weeklyProgress = useMemo(() => {
    const weeks: Record<number, number> = {};
    Object.values(store.state.tasks).forEach(task => {
      if (task.status === 'done' || task.status === 'partial') {
        const day = store.schedule.find(d => d.date === task.date);
        if (day) {
          weeks[day.week] = (weeks[day.week] || 0) + task.lecturesDone + task.extraLectures;
        }
      }
    });
    return Array.from({ length: 24 }, (_, i) => ({
      week: i + 1,
      lectures: weeks[i + 1] || 0,
    }));
  }, [store.state.tasks, store.schedule]);

  // Task completion rate
  const taskStats = useMemo(() => {
    const tasks = Object.values(store.state.tasks);
    const total = tasks.length;
    if (!total) return { done: 0, partial: 0, missed: 0, pending: 0, rate: 0 };
    const done = tasks.filter(t => t.status === 'done').length;
    const partial = tasks.filter(t => t.status === 'partial').length;
    const missed = tasks.filter(t => t.status === 'not-done').length;
    return {
      done, partial, missed, pending: total - done - partial - missed,
      rate: Math.round(((done + partial * 0.5) / total) * 100),
    };
  }, [store.state.tasks]);

  // Per-subject test performance
  const subjectTestData = useMemo(() =>
    SUBJECTS.map(s => {
      const tests = s.chapters.flatMap(ch =>
        (store.state.chapters[ch.id]?.testsDone || []).map(t => Math.round((t.score / t.maxScore) * 100))
      );
      return {
        name: s.label,
        color: s.color,
        avg: tests.length ? Math.round(tests.reduce((a, b) => a + b, 0) / tests.length) : 0,
        count: tests.length,
      };
    }),
  [store.state.chapters]);

  const pieData = subjectData.map(s => ({ name: s.name, value: s.done || 0.1, color: s.color }));
  const totalDone = subjectData.reduce((s, d) => s + d.done, 0);

  return (
    <div className="space-y-5 p-4 md:p-6 anim-fade-scale">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">📊 Analytics Dashboard</h1>
        <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
          Your study performance, test scores, and progress metrics
        </p>
      </div>

      {/* Top metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 stagger">
        {[
          { icon: '🎯', label: 'Completion Rate', value: `${store.getOverallProgress().pct}%`, color: '#6c63ff' },
          { icon: '📋', label: 'Tasks Completed', value: taskStats.done, color: '#00e5a0' },
          { icon: '❌', label: 'Tasks Missed', value: taskStats.missed, color: '#ff4d6d' },
          { icon: '🔥', label: 'Study Streak', value: `${store.state.streak}d`, color: '#ffb347' },
        ].map((m, i) => (
          <div key={i} className="metric-widget anim-fade-up">
            <div className="text-2xl mb-1">{m.icon}</div>
            <div className="text-2xl font-black" style={{ color: m.color }}>{m.value}</div>
            <div className="text-xs font-semibold text-white mt-0.5">{m.label}</div>
          </div>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Lecture Completion by Subject — Bar */}
        <div className="card-3d p-5">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            📚 Lectures: Done vs Remaining
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={subjectData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="name" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} />
              <Tooltip contentStyle={tooltipStyle} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
              <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }} />
              <Bar dataKey="done" name="Done" radius={[4, 4, 0, 0]}>
                {subjectData.map(d => <Cell key={d.name} fill={d.color} />)}
              </Bar>
              <Bar dataKey="remaining" name="Remaining" radius={[4, 4, 0, 0]}>
                {subjectData.map(d => <Cell key={d.name} fill={`${d.color}33`} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart */}
        <div className="card-3d p-5">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            🍕 Lecture Distribution
          </h3>
          {totalDone > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%" cy="50%"
                  innerRadius={55} outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  labelLine={false}
                  label={CustomLabel}
                >
                  {pieData.map(d => (
                    <Cell key={d.name} fill={d.color}
                      stroke={`${d.color}33`} strokeWidth={2}
                      style={{ filter: `drop-shadow(0 0 6px ${d.color}66)` }} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend
                  iconType="circle" iconSize={8}
                  wrapperStyle={{ color: 'rgba(255,255,255,0.6)', fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[220px]" style={{ color: 'rgba(255,255,255,0.3)' }}>
              Start studying to see your distribution!
            </div>
          )}
        </div>
      </div>

      {/* Weekly Lectures Chart */}
      <div className="card-3d p-5">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
          📈 Weekly Lecture Completion
        </h3>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={weeklyProgress} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
            <defs>
              <linearGradient id="weekGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6c63ff" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#6c63ff" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="week" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
              label={{ value: 'Week', position: 'insideBottom', fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} />
            <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} />
            <Tooltip contentStyle={tooltipStyle} />
            <Area type="monotone" dataKey="lectures" name="Lectures"
              stroke="#6c63ff" fill="url(#weekGrad)" strokeWidth={2}
              dot={{ fill: '#6c63ff', r: 3 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Test Performance Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Per-subject test avg */}
        <div className="card-3d p-5">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            🧪 Average Test Score by Subject
          </h3>
          {subjectTestData.every(s => s.count === 0) ? (
            <div className="text-center py-10" style={{ color: 'rgba(255,255,255,0.3)' }}>
              No tests recorded yet. Add tests in Chapter Tracker.
            </div>
          ) : (
            <div className="space-y-3">
              {subjectTestData.map(s => (
                <div key={s.name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-white font-semibold">{s.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>{s.count} tests</span>
                      <span className="text-sm font-black" style={{
                        color: s.avg >= 80 ? '#00e5a0' : s.avg >= 60 ? '#ffb347' : s.count === 0 ? 'rgba(255,255,255,0.3)' : '#ff4d6d'
                      }}>
                        {s.count > 0 ? `${s.avg}%` : 'N/A'}
                      </span>
                    </div>
                  </div>
                  <div className="progress-3d">
                    <div className="progress-fill" style={{
                      width: `${s.avg}%`,
                      background: s.avg >= 80 ? 'linear-gradient(90deg, #00b87a, #00e5a0)' :
                                  s.avg >= 60 ? 'linear-gradient(90deg, #d4900f, #ffb347)' :
                                  s.count === 0 ? 'transparent' :
                                  'linear-gradient(90deg, #c0243a, #ff4d6d)',
                    }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Task status pie */}
        <div className="card-3d p-5">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            📋 Task Completion Status
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Done',    value: taskStats.done,    color: '#00e5a0', icon: '✅' },
              { label: 'Partial', value: taskStats.partial,  color: '#ffb347', icon: '📊' },
              { label: 'Missed',  value: taskStats.missed,  color: '#ff4d6d', icon: '❌' },
              { label: 'Pending', value: taskStats.pending, color: '#6c63ff', icon: '⏳' },
            ].map(item => (
              <div key={item.label} className="metric-widget text-center py-4">
                <div className="text-2xl mb-1">{item.icon}</div>
                <div className="text-xl font-black" style={{ color: item.color }}>{item.value}</div>
                <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>{item.label}</div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-xs mb-1" style={{ color: 'rgba(255,255,255,0.5)' }}>
              <span>Overall Consistency</span>
              <span className="font-bold text-white">{taskStats.rate}%</span>
            </div>
            <div className="progress-3d" style={{ height: 12 }}>
              <div className="progress-fill" style={{
                width: `${taskStats.rate}%`,
                background: 'linear-gradient(90deg, #6c63ff, #00d4ff)',
                boxShadow: '0 0 15px rgba(108,99,255,0.4)',
              }} />
            </div>
          </div>
        </div>
      </div>

      {/* Test History Timeline */}
      {allTests.length > 0 && (
        <div className="card-3d p-5">
          <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            📈 Test Score History
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={allTests} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 9 }} />
              <YAxis domain={[0, 100]} tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} />
              <Tooltip contentStyle={tooltipStyle}
                formatter={(val: any, _n: any, p: any) => [`${val}%`, p.payload.subject]} />
              <Line type="monotone" dataKey="pct" name="Score"
                stroke="#00d4ff" strokeWidth={2}
                dot={(props: any) => {
                  const { cx, cy, payload } = props;
                  return <circle key={payload.date} cx={cx} cy={cy} r={4}
                    fill={payload.pct >= 80 ? '#00e5a0' : payload.pct >= 60 ? '#ffb347' : '#ff4d6d'}
                    stroke="none" />;
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
