import { useMemo } from 'react';
import { SUBJECTS, MONTHLY_TARGETS } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';

type Store = ReturnType<typeof usePlannerStore>;

interface Props { store: Store; }

export default function Dashboard({ store }: Props) {
  const overall = store.getOverallProgress();

  const subjectStats = useMemo(() =>
    SUBJECTS.map(s => ({
      ...s,
      progress: store.getSubjectProgress(s.key),
    })),
  [store]);

  const today = new Date().toISOString().split('T')[0];
  const todaySchedule = store.getDaySchedule(today);

  const totalTests = Object.values(store.state.chapters)
    .reduce((s, c) => s + c.testsDone.length, 0);

  const avgScore = useMemo(() => {
    const allTests = Object.values(store.state.chapters).flatMap(c => c.testsDone);
    if (!allTests.length) return 0;
    const pcts = allTests.map(t => (t.score / t.maxScore) * 100);
    return Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length);
  }, [store.state.chapters]);

  return (
    <div className="space-y-6 p-4 md:p-6 anim-fade-scale">

      {/* ── Header ── */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">
            🎯 Command Center
          </h1>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.45)' }}>
            Anurag Singh Indoliya · Class 12 PCM · Target: December 2025
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="card-extruded px-4 py-2 flex items-center gap-2">
            <span className="text-2xl">🔥</span>
            <div>
              <div className="text-lg font-black text-white leading-none">{store.state.streak}</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Day Streak</div>
            </div>
          </div>
          <div className="card-extruded px-4 py-2 flex items-center gap-2">
            <span className="text-2xl">📋</span>
            <div>
              <div className="text-lg font-black text-white leading-none">{totalTests}</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Tests Done</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Top Row: Overall Progress + Radial ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Overall Circle */}
        <div className="card-3d p-6 flex flex-col items-center justify-center relative overflow-hidden"
          style={{ minHeight: 220 }}>
          <div className="absolute inset-0 star-grid opacity-30 pointer-events-none" />
          <div className="relative flex flex-col items-center">
            <div className="relative w-36 h-36">
              <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                <circle cx="60" cy="60" r="52" fill="none"
                  stroke="rgba(255,255,255,0.07)" strokeWidth="10" />
                <circle cx="60" cy="60" r="52" fill="none"
                  stroke="url(#overallGrad)" strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 52}`}
                  strokeDashoffset={`${2 * Math.PI * 52 * (1 - overall.pct / 100)}`}
                  style={{ transition: 'stroke-dashoffset 0.8s ease' }}
                />
                <defs>
                  <linearGradient id="overallGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6c63ff" />
                    <stop offset="100%" stopColor="#00d4ff" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center rotate-0">
                <span className="text-3xl font-black text-white">{overall.pct}%</span>
                <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Complete</span>
              </div>
            </div>
            <div className="mt-4 text-center">
              <div className="text-base font-bold text-white">Overall Syllabus</div>
              <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
                {overall.done}/{overall.total} lectures · {overall.doneCh}/{overall.totalCh} chapters
              </div>
            </div>
          </div>
        </div>

        {/* Subject Progress Bars */}
        <div className="lg:col-span-2 card-3d p-5 space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest"
            style={{ color: 'rgba(255,255,255,0.4)' }}>Subject Progress</h2>
          <div className="space-y-3 stagger">
            {subjectStats.map(s => (
              <div key={s.key} className="anim-fade-up">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{s.icon}</span>
                    <span className="text-sm font-semibold text-white">{s.label}</span>
                    <span className="badge-3d text-xs" style={{ color: s.color, borderColor: s.color, boxShadow: `0 0 8px ${s.glow}` }}>
                      {s.progress.doneChapters}/{s.progress.totalChapters} ch
                    </span>
                  </div>
                  <span className="text-sm font-bold" style={{ color: s.color }}>
                    {s.progress.pct}%
                  </span>
                </div>
                <div className="progress-3d">
                  <div
                    className="progress-fill"
                    style={{
                      width: `${s.progress.pct}%`,
                      background: `linear-gradient(90deg, ${s.color}99, ${s.color})`,
                      boxShadow: `0 0 10px ${s.glow}`,
                    }}
                  />
                </div>
                <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.3)' }}>
                  {s.progress.doneLectures}/{s.progress.totalLectures} lectures
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Metric Widgets Row ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 stagger">
        {[
          { icon: '📚', label: 'Lectures Done',   value: overall.done,         sub: `of ${overall.total}`, color: '#6c63ff' },
          { icon: '✅', label: 'Chapters Done',   value: overall.doneCh,       sub: `of ${overall.totalCh}`, color: '#00e5a0' },
          { icon: '🧪', label: 'Tests Attempted', value: totalTests,           sub: 'all subjects',    color: '#00d4ff' },
          { icon: '⭐', label: 'Avg Test Score',  value: `${avgScore}%`,       sub: 'across all tests', color: '#ffb347' },
        ].map((m, i) => (
          <div key={i} className="metric-widget anim-fade-up">
            <div className="text-2xl mb-2">{m.icon}</div>
            <div className="text-2xl font-black" style={{ color: m.color }}>{m.value}</div>
            <div className="text-xs font-semibold text-white mt-0.5">{m.label}</div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* ── Today's Schedule ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="card-3d p-5">
          <h2 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            📅 Today's Plan ({new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' })})
          </h2>
          {todaySchedule ? (
            todaySchedule.dayType === 'SUNDAY' ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-2">🌟</div>
                <div className="text-white font-bold text-lg">Sunday — Rest Day</div>
                <div className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>Zero study. Recharge completely.</div>
              </div>
            ) : (
              <div className="space-y-3">
                {todaySchedule.blocks.map(block => {
                  const subj = SUBJECTS.find(s => s.key === block.subject)!;
                  const task = store.getTask(block.id, today);
                  return (
                    <div key={block.id} className="card-extruded p-4 subject-card"
                      style={{ ['--subj-color' as string]: subj.color, ['--subj-glow' as string]: subj.glow }}>
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{subj.icon}</span>
                            <span className="font-bold text-white">{block.label}</span>
                            {todaySchedule.isHybridDay && (
                              <span className="badge-3d" style={{ color: '#ffb347', borderColor: '#ffb347' }}>HYBRID</span>
                            )}
                          </div>
                          <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
                            {block.timeSlot} · {block.lecturesPlanned} lecture{block.lecturesPlanned > 1 ? 's' : ''} planned
                          </div>
                        </div>
                        <div className={`badge-3d ${
                          task.status === 'done' ? 'text-green-400' :
                          task.status === 'not-done' ? 'text-red-400' :
                          task.status === 'partial' ? 'text-yellow-400' : 'text-gray-400'
                        }`} style={{
                          color: task.status === 'done' ? '#00e5a0' : task.status === 'not-done' ? '#ff4d6d' : task.status === 'partial' ? '#ffb347' : 'rgba(255,255,255,0.4)',
                          borderColor: task.status === 'done' ? '#00e5a0' : task.status === 'not-done' ? '#ff4d6d' : task.status === 'partial' ? '#ffb347' : 'rgba(255,255,255,0.2)',
                        }}>
                          {task.status === 'done' ? '✓ Done' : task.status === 'not-done' ? '✗ Missed' : task.status === 'partial' ? '~ Partial' : '⏳ Pending'}
                        </div>
                      </div>
                      <div className="flex gap-2 mt-3">
                        {(['done', 'partial', 'not-done'] as const).map(s => (
                          <button key={s}
                            onClick={() => store.updateTask(block.id, today, { status: s, lecturesDone: s === 'done' ? block.lecturesPlanned : task.lecturesDone })}
                            className="btn-3d btn-ghost text-xs px-3 py-1.5 flex-1"
                            style={task.status === s ? { background: subj.glow, borderColor: subj.color, color: subj.color } : {}}>
                            {s === 'done' ? '✅ Done' : s === 'partial' ? '📊 Partial' : '❌ Missed'}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
                <div className="card-extruded p-3 flex items-center gap-3">
                  <span className="text-xl">📵</span>
                  <div className="text-sm">
                    <div className="font-semibold text-white">Focus Mode Reminder</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)' }} className="text-xs">Set Samsung Galaxy Tab A9 to Focus Mode before Block 1 & Block 2</div>
                  </div>
                </div>
              </div>
            )
          ) : (
            <div className="text-center py-8" style={{ color: 'rgba(255,255,255,0.4)' }}>Schedule not found for today</div>
          )}
        </div>

        {/* Monthly Pacing Guide */}
        <div className="card-3d p-5">
          <h2 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
            🗓️ Monthly Pacing Guide
          </h2>
          <div className="space-y-2 overflow-y-auto" style={{ maxHeight: 380 }}>
            {MONTHLY_TARGETS.map((m, i) => (
              <div key={i} className="card-extruded p-3">
                <div className="flex items-start justify-between">
                  <div className="font-bold text-white text-sm">{m.month}</div>
                  <span className="badge-3d text-xs"
                    style={{
                      color: m.phase === 'FINAL' ? '#ffb347' : m.phase === '1' ? '#00e5a0' : '#6c63ff',
                      borderColor: m.phase === 'FINAL' ? '#ffb347' : m.phase === '1' ? '#00e5a0' : '#6c63ff',
                    }}>
                    Phase {m.phase}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1 mt-2">
                  {[
                    { label: 'Physics', val: m.physicsChapters, color: '#00d4ff' },
                    { label: 'Chem', val: m.chemistryChapters, color: '#00e5a0' },
                    { label: 'Math', val: m.mathChapters, color: '#6c63ff' },
                  ].map(x => (
                    <div key={x.label} className="text-center rounded-lg p-1" style={{ background: 'rgba(255,255,255,0.04)' }}>
                      <div className="text-sm font-black" style={{ color: x.color }}>{x.val}</div>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{x.label}</div>
                    </div>
                  ))}
                </div>
                <p className="text-xs mt-2" style={{ color: 'rgba(255,255,255,0.4)' }}>{m.note}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Phase Info Cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Phase 1 */}
        <div className="card-3d p-5" style={{ borderTop: '2px solid #00e5a0', boxShadow: 'var(--shadow-lg), 0 -2px 20px rgba(0,229,160,0.2)' }}>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">🌱</span>
            <h3 className="font-bold text-white">Phase 1: Rhythm Builder (Weeks 1–3)</h3>
          </div>
          <div className="space-y-2 text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
            <div className="flex gap-2"><span className="text-green-400">▶</span> Alternate Day A (Phy+Chem) & Day B (Math+Lang)</div>
            <div className="flex gap-2"><span className="text-green-400">▶</span> <b className="text-white">1 lecture/session</b> for all primary subjects</div>
            <div className="flex gap-2"><span className="text-green-400">▶</span> First 20 min = Revise previous lecture notes</div>
            <div className="flex gap-2"><span className="text-green-400">▶</span> Language blocks = 45 minutes on Day B</div>
            <div className="flex gap-2"><span className="text-green-400">▶</span> 3–4 hour gap between Block 1 & Block 2</div>
            <div className="flex gap-2"><span className="text-green-400">▶</span> Sunday = Complete rest day 🎯</div>
          </div>
        </div>

        {/* Phase 2 */}
        <div className="card-3d p-5" style={{ borderTop: '2px solid #6c63ff', boxShadow: 'var(--shadow-lg), 0 -2px 20px rgba(108,99,255,0.2)' }}>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">🚀</span>
            <h3 className="font-bold text-white">Phase 2: Final Execution (Weeks 4–24)</h3>
          </div>
          <div className="space-y-2 text-sm" style={{ color: 'rgba(255,255,255,0.6)' }}>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Physics & Math: <b className="text-white">2 lectures/block</b></div>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Chemistry: stays at <b className="text-white">1 lecture/block</b></div>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Mon–Thu: 15-20 min review at start of block</div>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Friday (Hybrid): 1 new lecture + Spaced Recall (Phy/Chem)</div>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Saturday (Hybrid): 1 new lecture + Blank-Sheet Method (Math/Lang)</div>
            <div className="flex gap-2"><span className="text-purple-400">▶</span> Device: Tab A9 in Focus Mode all study blocks 📵</div>
          </div>
        </div>
      </div>
    </div>
  );
}
