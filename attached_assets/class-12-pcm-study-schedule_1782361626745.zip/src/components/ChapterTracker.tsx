import { useState } from 'react';
import { SUBJECTS } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';
import type { TestRecord } from '../store/plannerStore';

type Store = ReturnType<typeof usePlannerStore>;
interface Props { store: Store; }

const TEST_TYPES = ['chapter', 'unit', 'mock', 'practice'] as const;

function TestModal({ chapterId, store, onClose }: {
  chapterId: string; store: Store; onClose: () => void;
}) {
  const ch = store.state.chapters[chapterId];
  const [form, setForm] = useState({
    date: new Date().toISOString().split('T')[0],
    score: '',
    maxScore: '100',
    type: 'chapter' as TestRecord['type'],
    notes: '',
  });
  const [editId, setEditId] = useState<string | null>(null);

  const handleAdd = () => {
    if (!form.score) return;
    store.addTest(chapterId, {
      date: form.date,
      score: parseFloat(form.score),
      maxScore: parseFloat(form.maxScore),
      type: form.type,
      notes: form.notes,
    });
    setForm({ date: new Date().toISOString().split('T')[0], score: '', maxScore: '100', type: 'chapter', notes: '' });
  };

  const handleEdit = (test: TestRecord) => {
    setEditId(test.id);
    setForm({ date: test.date, score: test.score.toString(), maxScore: test.maxScore.toString(), type: test.type, notes: test.notes });
  };

  const handleUpdate = () => {
    if (!editId || !form.score) return;
    store.updateTest(chapterId, editId, {
      date: form.date,
      score: parseFloat(form.score),
      maxScore: parseFloat(form.maxScore),
      type: form.type,
      notes: form.notes,
    });
    setEditId(null);
    setForm({ date: new Date().toISOString().split('T')[0], score: '', maxScore: '100', type: 'chapter', notes: '' });
  };

  const subj = SUBJECTS.find(s => s.key === ch.subject)!;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="card-3d p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto anim-fade-scale">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-lg font-bold text-white">🧪 Test Records</h3>
            <p className="text-xs mt-1" style={{ color: subj.color }}>{ch.chapterId}</p>
          </div>
          <button onClick={onClose} className="btn-3d btn-ghost w-9 h-9 rounded-full p-0 text-lg">✕</button>
        </div>

        {/* Add/Edit Form */}
        <div className="card-extruded p-4 mb-4">
          <h4 className="text-sm font-bold text-white mb-3">{editId ? '✏️ Edit Test' : '➕ Add Test'}</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>Date</label>
              <input type="date" value={form.date}
                onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                className="input-3d text-sm py-2" />
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>Type</label>
              <select value={form.type}
                onChange={e => setForm(f => ({ ...f, type: e.target.value as TestRecord['type'] }))}
                className="input-3d text-sm py-2">
                {TEST_TYPES.map(t => <option key={t} value={t} style={{ background: '#0f1326' }}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>Score</label>
              <input type="number" min="0" value={form.score}
                onChange={e => setForm(f => ({ ...f, score: e.target.value }))}
                className="input-3d text-sm py-2" placeholder="e.g. 85" />
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>Max Score</label>
              <input type="number" min="1" value={form.maxScore}
                onChange={e => setForm(f => ({ ...f, maxScore: e.target.value }))}
                className="input-3d text-sm py-2" placeholder="e.g. 100" />
            </div>
          </div>
          <div className="mt-3">
            <label className="text-xs mb-1 block" style={{ color: 'rgba(255,255,255,0.5)' }}>Notes</label>
            <input type="text" value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="input-3d text-sm py-2" placeholder="e.g. Struggled with integration by parts" />
          </div>
          {form.score && (
            <div className="mt-3 flex items-center gap-2">
              <div className="text-sm font-bold" style={{
                color: (parseFloat(form.score) / parseFloat(form.maxScore)) >= 0.8 ? '#00e5a0' :
                       (parseFloat(form.score) / parseFloat(form.maxScore)) >= 0.6 ? '#ffb347' : '#ff4d6d'
              }}>
                {Math.round((parseFloat(form.score) / parseFloat(form.maxScore)) * 100)}%
              </div>
              <div className="flex-1 progress-3d" style={{ height: 6 }}>
                <div className="progress-fill" style={{
                  width: `${(parseFloat(form.score) / parseFloat(form.maxScore)) * 100}%`,
                  background: (parseFloat(form.score) / parseFloat(form.maxScore)) >= 0.8 ? '#00e5a0' :
                              (parseFloat(form.score) / parseFloat(form.maxScore)) >= 0.6 ? '#ffb347' : '#ff4d6d',
                }} />
              </div>
            </div>
          )}
          <div className="flex gap-2 mt-3">
            {editId ? (
              <>
                <button onClick={handleUpdate} className="btn-3d btn-primary flex-1 text-sm py-2">💾 Update</button>
                <button onClick={() => { setEditId(null); setForm({ date: new Date().toISOString().split('T')[0], score: '', maxScore: '100', type: 'chapter', notes: '' }); }}
                  className="btn-3d btn-ghost text-sm py-2 px-4">Cancel</button>
              </>
            ) : (
              <button onClick={handleAdd} className="btn-3d btn-success flex-1 text-sm py-2">➕ Add Test</button>
            )}
          </div>
        </div>

        {/* Test List */}
        {ch.testsDone.length === 0 ? (
          <div className="text-center py-8" style={{ color: 'rgba(255,255,255,0.3)' }}>
            No tests yet. Add your first test above.
          </div>
        ) : (
          <div className="space-y-2">
            {ch.testsDone.map(test => {
              const pct = Math.round((test.score / test.maxScore) * 100);
              return (
                <div key={test.id} className="card-extruded p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="badge-3d text-xs" style={{ color: subj.color, borderColor: subj.color }}>{test.type}</span>
                      <span className="text-xs text-white">{new Date(test.date + 'T00:00:00').toLocaleDateString('en-IN')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-lg" style={{
                        color: pct >= 80 ? '#00e5a0' : pct >= 60 ? '#ffb347' : '#ff4d6d'
                      }}>
                        {pct}%
                      </span>
                      <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>{test.score}/{test.maxScore}</span>
                      <button onClick={() => handleEdit(test)}
                        className="btn-3d btn-ghost w-7 h-7 p-0 text-sm rounded-lg">✏️</button>
                      <button onClick={() => store.deleteTest(chapterId, test.id)}
                        className="btn-3d btn-danger w-7 h-7 p-0 text-sm rounded-lg">🗑</button>
                    </div>
                  </div>
                  {test.notes && (
                    <p className="text-xs mt-1.5 italic" style={{ color: 'rgba(255,255,255,0.4)' }}>💬 {test.notes}</p>
                  )}
                  <div className="mt-2 progress-3d" style={{ height: 4 }}>
                    <div className="progress-fill" style={{
                      width: `${pct}%`,
                      background: pct >= 80 ? '#00e5a0' : pct >= 60 ? '#ffb347' : '#ff4d6d',
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function ChapterRow({ chapterId, store }: { chapterId: string; store: Store }) {
  const ch = store.state.chapters[chapterId];
  const subj = SUBJECTS.find(s => s.key === ch.subject)!;
  const subjData = subj.chapters.find(c => c.id === chapterId)!;
  const [showTests, setShowTests] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [editLectures, setEditLectures] = useState(false);
  const [totalInput, setTotalInput] = useState(ch.totalLectures.toString());
  const pct = Math.min(100, Math.round((ch.lecturesWatched / ch.totalLectures) * 100));
  const avgTest = ch.testsDone.length
    ? Math.round(ch.testsDone.reduce((s, t) => s + (t.score / t.maxScore) * 100, 0) / ch.testsDone.length)
    : null;

  return (
    <>
      {showTests && <TestModal chapterId={chapterId} store={store} onClose={() => setShowTests(false)} />}
      <div
        className="card-extruded p-4 transition-all"
        style={{
          borderLeft: `3px solid ${ch.completed ? '#00e5a0' : subj.color}`,
          boxShadow: ch.completed
            ? 'var(--shadow-md), -2px 0 16px rgba(0,229,160,0.2)'
            : `var(--shadow-md), -2px 0 12px ${subj.glow}`,
          opacity: ch.completed ? 0.9 : 1,
        }}
      >
        <div className="flex items-start gap-3">
          {/* Checkbox */}
          <div className="flex-shrink-0 mt-0.5">
            <input
              type="checkbox"
              checked={ch.completed}
              onChange={() => store.toggleChapterComplete(chapterId)}
              className="checkbox-3d"
            />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 flex-wrap">
              <div>
                <span className={`font-semibold text-sm ${ch.completed ? 'line-through' : ''} text-white`}>
                  {subjData?.name || chapterId}
                </span>
                {subjData?.isBasics && (
                  <span className="ml-2 badge-3d" style={{ color: '#ffb347', borderColor: '#ffb347', fontSize: '0.6rem' }}>BASICS</span>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap flex-shrink-0">
                {ch.testsDone.length > 0 && (
                  <span className="badge-3d" style={{
                    color: avgTest! >= 80 ? '#00e5a0' : avgTest! >= 60 ? '#ffb347' : '#ff4d6d',
                    borderColor: avgTest! >= 80 ? '#00e5a0' : avgTest! >= 60 ? '#ffb347' : '#ff4d6d',
                  }}>
                    Avg: {avgTest}%
                  </span>
                )}
                {ch.completed && (
                  <span className="badge-3d" style={{ color: '#00e5a0', borderColor: '#00e5a0' }}>✓ Done</span>
                )}
              </div>
            </div>

            {/* Progress bar */}
            <div className="flex items-center gap-3 mt-2">
              <div className="flex-1 progress-3d">
                <div className="progress-fill" style={{
                  width: `${pct}%`,
                  background: ch.completed
                    ? 'linear-gradient(90deg, #00b87a, #00e5a0)'
                    : `linear-gradient(90deg, ${subj.color}80, ${subj.color})`,
                  boxShadow: ch.completed ? '0 0 8px rgba(0,229,160,0.4)' : `0 0 8px ${subj.glow}`,
                }} />
              </div>
              <span className="text-xs font-bold flex-shrink-0" style={{ color: ch.completed ? '#00e5a0' : subj.color }}>
                {pct}%
              </span>
            </div>

            {/* Lecture counter */}
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>Lectures:</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => store.updateLectures(chapterId, Math.max(0, ch.lecturesWatched - 1))}
                    className="btn-3d btn-ghost w-6 h-6 p-0 text-sm rounded-lg">−</button>
                  <span className="text-sm font-bold text-white w-8 text-center">{ch.lecturesWatched}</span>
                  <button
                    onClick={() => store.updateLectures(chapterId, ch.lecturesWatched + 1)}
                    className="btn-3d btn-ghost w-6 h-6 p-0 text-sm rounded-lg">+</button>
                  <span className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>/ </span>
                  {editLectures ? (
                    <div className="flex items-center gap-1">
                      <input type="number" min="1" max="50" value={totalInput}
                        onChange={e => setTotalInput(e.target.value)}
                        className="input-3d text-xs py-0.5 w-14"
                        style={{ padding: '3px 6px' }} />
                      <button onClick={() => { store.updateTotalLectures(chapterId, parseInt(totalInput) || ch.totalLectures); setEditLectures(false); }}
                        className="btn-3d btn-success text-xs px-2 py-0.5">✓</button>
                    </div>
                  ) : (
                    <button onClick={() => setEditLectures(true)}
                      className="text-xs font-bold hover:underline cursor-pointer"
                      style={{ color: subj.color }}>
                      {ch.totalLectures} ✏️
                    </button>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-1.5 ml-auto">
                <button onClick={() => setShowTests(true)}
                  className="btn-3d btn-ghost text-xs px-3 py-1.5 flex items-center gap-1">
                  🧪 Tests {ch.testsDone.length > 0 ? `(${ch.testsDone.length})` : ''}
                </button>
                <button onClick={() => setShowNotes(!showNotes)}
                  className="btn-3d btn-ghost text-xs px-3 py-1.5">
                  📝 Notes
                </button>
              </div>
            </div>

            {/* Notes */}
            {showNotes && (
              <div className="mt-3">
                <textarea
                  value={ch.notes}
                  onChange={e => store.updateChapterNotes(chapterId, e.target.value)}
                  className="input-3d text-sm w-full"
                  rows={3}
                  placeholder="Add chapter notes, weak areas, resources..."
                  style={{ resize: 'vertical' }}
                />
              </div>
            )}

            {/* Start/Complete dates */}
            {(ch.startedAt || ch.completedAt) && (
              <div className="flex gap-4 mt-2 text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>
                {ch.startedAt && <span>Started: {new Date(ch.startedAt).toLocaleDateString('en-IN')}</span>}
                {ch.completedAt && <span>✅ Completed: {new Date(ch.completedAt).toLocaleDateString('en-IN')}</span>}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default function ChapterTracker({ store }: Props) {
  const [activeSubject, setActiveSubject] = useState<string>('physics');
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'started'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const subj = SUBJECTS.find(s => s.key === activeSubject)!;
  const progress = store.getSubjectProgress(subj.key as Parameters<typeof store.getSubjectProgress>[0]);

  const filteredChapters = subj.chapters.filter(ch => {
    const status = store.state.chapters[ch.id];
    if (!status) return filter === 'all';
    const matchesSearch = ch.name.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (filter === 'completed') return status.completed;
    if (filter === 'pending') return !status.completed && status.lecturesWatched === 0;
    if (filter === 'started') return !status.completed && status.lecturesWatched > 0;
    return true;
  });

  return (
    <div className="space-y-5 p-4 md:p-6 anim-fade-scale">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">📚 Chapter Tracker</h1>
        <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
          Track progress, tests, and notes for every chapter
        </p>
      </div>

      {/* Subject Tabs */}
      <div className="flex gap-2 flex-wrap">
        {SUBJECTS.map(s => {
          const p = store.getSubjectProgress(s.key);
          return (
            <button key={s.key} onClick={() => setActiveSubject(s.key)}
              className={`nav-tab ${activeSubject === s.key ? 'active' : ''}`}
              style={activeSubject === s.key ? { borderColor: s.color, color: s.color } : {}}>
              {s.icon} {s.label}
              <span className="ml-1 text-xs opacity-60">{p.doneChapters}/{p.totalChapters}</span>
            </button>
          );
        })}
      </div>

      {/* Subject Progress Card */}
      <div className="card-3d p-5" style={{ borderTop: `2px solid ${subj.color}` }}>
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex items-center gap-3 flex-1">
            <span className="text-3xl">{subj.icon}</span>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h2 className="font-black text-white text-lg">{subj.label}</h2>
                <span className="text-2xl font-black" style={{ color: subj.color }}>{progress.pct}%</span>
              </div>
              <div className="progress-3d">
                <div className="progress-fill" style={{
                  width: `${progress.pct}%`,
                  background: `linear-gradient(90deg, ${subj.color}80, ${subj.color})`,
                  boxShadow: `0 0 12px ${subj.glow}`,
                }} />
              </div>
              <div className="flex gap-4 mt-2 text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
                <span>📖 {progress.doneLectures}/{progress.totalLectures} lectures</span>
                <span>✅ {progress.doneChapters}/{progress.totalChapters} chapters</span>
                <span>🧪 {subj.chapters.reduce((s, c) => s + (store.state.chapters[c.id]?.testsDone.length || 0), 0)} tests</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="input-3d flex-1"
          placeholder="🔍 Search chapters..."
        />
        <div className="flex gap-2 flex-wrap">
          {(['all', 'started', 'pending', 'completed'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`nav-tab text-sm ${filter === f ? 'active' : ''}`}>
              {f === 'all' ? '📋 All' : f === 'started' ? '▶️ In Progress' : f === 'pending' ? '⏳ Pending' : '✅ Done'}
            </button>
          ))}
        </div>
      </div>

      {/* Chapter List */}
      <div className="space-y-3 stagger">
        {filteredChapters.length === 0 ? (
          <div className="card-3d p-10 text-center" style={{ color: 'rgba(255,255,255,0.3)' }}>
            No chapters match your filter
          </div>
        ) : (
          filteredChapters.map((ch, i) => (
            <div key={ch.id} className="anim-fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
              <ChapterRow chapterId={ch.id} store={store} />
            </div>
          ))
        )}
      </div>
    </div>
  );
}
