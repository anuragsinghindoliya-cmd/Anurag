import { useState, useMemo } from 'react';
import { SUBJECTS } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';
import type { DaySchedule, Block } from '../data/plannerData';

type Store = ReturnType<typeof usePlannerStore>;
interface Props { store: Store; }

const DAY_LABELS: Record<string, string> = {
  Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday',
  Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday',
};

const STATUS_CONFIG = {
  pending:  { label: '⏳ Pending',  bg: 'rgba(255,255,255,0.04)', border: 'rgba(255,255,255,0.08)', text: 'rgba(255,255,255,0.4)' },
  done:     { label: '✅ Done',      bg: 'rgba(0,229,160,0.08)',  border: 'rgba(0,229,160,0.3)',   text: '#00e5a0' },
  'not-done':{ label: '❌ Missed',   bg: 'rgba(255,77,109,0.08)', border: 'rgba(255,77,109,0.3)',  text: '#ff4d6d' },
  partial:  { label: '📊 Partial',  bg: 'rgba(255,179,71,0.08)', border: 'rgba(255,179,71,0.3)',  text: '#ffb347' },
};

function BlockCard({ block, date, store, phase, isHybrid }: {
  block: Block; date: string; store: Store; phase: 1 | 2; isHybrid: boolean;
}) {
  const subj = SUBJECTS.find(s => s.key === block.subject)!;
  const task = store.getTask(block.id, date);
  const sc = STATUS_CONFIG[task.status];
  const [showExtra, setShowExtra] = useState(false);
  const [extra, setExtra] = useState(task.extraLectures.toString());

  const handleStatus = (status: 'done' | 'not-done' | 'partial') => {
    store.updateTask(block.id, date, {
      status,
      lecturesDone: status === 'done' ? block.lecturesPlanned + task.extraLectures : task.lecturesDone,
    });
  };

  const handleExtra = () => {
    const val = Math.max(0, parseInt(extra) || 0);
    store.updateTask(block.id, date, { extraLectures: val });
    setShowExtra(false);
  };

  return (
    <div
      className="card-extruded p-4 transition-all"
      style={{
        borderLeft: `3px solid ${subj.color}`,
        boxShadow: `var(--shadow-md), -2px 0 16px ${subj.glow}`,
        background: sc.bg,
        borderColor: sc.border,
        borderLeftColor: subj.color,
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xl">{subj.icon}</span>
          <span className="font-bold text-white text-sm">{block.label}</span>
          {isHybrid && (
            <span className="badge-3d" style={{ color: '#ffb347', borderColor: '#ffb347', fontSize: '0.6rem' }}>
              HYBRID
            </span>
          )}
          {block.blockType === 'revision' && (
            <span className="badge-3d" style={{ color: '#00d4ff', borderColor: '#00d4ff', fontSize: '0.6rem' }}>
              SPACED RECALL
            </span>
          )}
        </div>
        <span className="badge-3d text-xs flex-shrink-0" style={{ color: sc.text, borderColor: sc.text }}>
          {sc.label}
        </span>
      </div>

      {/* Time & Plan info */}
      <div className="text-xs mb-3 space-y-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
        <div>🕐 {block.timeSlot}</div>
        <div>
          📚 {block.lecturesPlanned} lecture{block.lecturesPlanned > 1 ? 's' : ''} planned
          {phase === 1 ? ' + 20 min revision at start' : ' + 15-20 min review'}
        </div>
        {task.extraLectures > 0 && (
          <div className="font-semibold" style={{ color: '#00e5a0' }}>
            ➕ {task.extraLectures} extra lecture{task.extraLectures > 1 ? 's' : ''} added!
          </div>
        )}
        {task.notes && (
          <div className="italic" style={{ color: 'rgba(255,255,255,0.5)' }}>💬 {task.notes}</div>
        )}
      </div>

      {/* Status Buttons */}
      <div className="flex gap-1.5 mb-2">
        {(['done', 'partial', 'not-done'] as const).map(s => (
          <button key={s}
            onClick={() => handleStatus(s)}
            className="btn-3d btn-ghost flex-1 text-xs py-1.5"
            style={task.status === s ? {
              background: s === 'done' ? 'rgba(0,229,160,0.15)' : s === 'not-done' ? 'rgba(255,77,109,0.15)' : 'rgba(255,179,71,0.15)',
              borderColor: s === 'done' ? '#00e5a0' : s === 'not-done' ? '#ff4d6d' : '#ffb347',
              color: s === 'done' ? '#00e5a0' : s === 'not-done' ? '#ff4d6d' : '#ffb347',
            } : {}}>
            {s === 'done' ? '✅' : s === 'partial' ? '📊' : '❌'}
          </button>
        ))}
        <button
          onClick={() => setShowExtra(!showExtra)}
          className="btn-3d btn-ghost text-xs px-2 py-1.5"
          style={{ color: '#6c63ff', borderColor: 'rgba(108,99,255,0.4)' }}
          title="Add extra lectures"
        >
          ➕
        </button>
      </div>

      {/* Extra lectures input */}
      {showExtra && (
        <div className="flex gap-2 mt-2">
          <input
            type="number" min="0" max="10"
            value={extra}
            onChange={e => setExtra(e.target.value)}
            className="input-3d text-sm py-1.5"
            placeholder="Extra lectures"
          />
          <button onClick={handleExtra} className="btn-3d btn-success text-xs px-3">Save</button>
          <button onClick={() => setShowExtra(false)} className="btn-3d btn-ghost text-xs px-3">✕</button>
        </div>
      )}
    </div>
  );
}

function DayCard({ day, store }: { day: DaySchedule; store: Store }) {
  const isSunday = day.dayType === 'SUNDAY';
  const isToday = day.date === new Date().toISOString().split('T')[0];

  const allDone = day.blocks.length > 0 && day.blocks.every(b => {
    const t = store.getTask(b.id, day.date);
    return t.status === 'done';
  });
  const anyMissed = day.blocks.some(b => store.getTask(b.id, day.date).status === 'not-done');

  return (
    <div
      className="card-3d overflow-hidden"
      style={isToday ? {
        borderColor: 'rgba(108,99,255,0.5)',
        boxShadow: 'var(--shadow-xl), 0 0 30px rgba(108,99,255,0.2)',
      } : {}}
    >
      {/* Day Header */}
      <div className="px-4 py-3 flex items-center justify-between"
        style={{
          background: isToday
            ? 'linear-gradient(135deg, rgba(108,99,255,0.2), rgba(0,212,255,0.1))'
            : isSunday
              ? 'linear-gradient(135deg, rgba(255,107,157,0.1), rgba(255,179,71,0.05))'
              : 'rgba(255,255,255,0.04)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
        }}>
        <div className="flex items-center gap-2">
          <span className="font-black text-white text-base">
            {DAY_LABELS[day.dayOfWeek] || day.dayOfWeek}
          </span>
          {isToday && (
            <span className="badge-3d" style={{ color: '#6c63ff', borderColor: '#6c63ff', fontSize: '0.6rem' }}>
              TODAY
            </span>
          )}
          {day.isHybridDay && (
            <span className="badge-3d" style={{ color: '#ffb347', borderColor: '#ffb347', fontSize: '0.6rem' }}>
              HYBRID
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>
            {new Date(day.date + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
          </span>
          {!isSunday && (
            <span className={`w-2.5 h-2.5 rounded-full ${
              allDone ? 'bg-green-400' : anyMissed ? 'bg-red-400' : 'bg-gray-600'
            }`} style={allDone ? { boxShadow: '0 0 8px #00e5a0' } : anyMissed ? { boxShadow: '0 0 8px #ff4d6d' } : {}} />
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {isSunday ? (
          <div className="flex items-center justify-center py-6 gap-3">
            <span className="text-3xl">🌟</span>
            <div>
              <div className="font-bold text-white">Rest & Recharge</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>
                Zero study day — personal downtime
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold uppercase tracking-widest"
                style={{ color: day.dayType === 'A' ? '#00d4ff' : '#6c63ff' }}>
                Day Type {day.dayType} · Phase {day.phase}
              </span>
              <div className="h-px flex-1" style={{ background: 'rgba(255,255,255,0.06)' }} />
              <span className="text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>
                Gap: 3–4h between blocks
              </span>
            </div>
            {day.blocks.map(block => (
              <BlockCard
                key={block.id}
                block={block}
                date={day.date}
                store={store}
                phase={day.phase}
                isHybrid={day.isHybridDay}
              />
            ))}
            {!day.isHybridDay && day.phase === 1 && (
              <div className="text-xs p-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.04)', color: 'rgba(255,255,255,0.35)' }}>
                📌 First 20 min of each block = Revise previous lecture
              </div>
            )}
            {day.isHybridDay && (
              <div className="text-xs p-2 rounded-lg" style={{ background: 'rgba(255,179,71,0.06)', color: '#ffb347', border: '1px solid rgba(255,179,71,0.15)' }}>
                ✍️ Blank-Sheet Method: Write formulas & theorems before opening books
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Timetable({ store }: Props) {
  const [viewMode, setViewMode] = useState<'week' | 'phase1' | 'phase2'>('week');
  const [currentWeek, setCurrentWeek] = useState(() => {
    const today = new Date().toISOString().split('T')[0];
    const day = store.schedule.find(d => d.date === today);
    return day?.week || 1;
  });

  const weekSchedule = useMemo(() =>
    store.getWeekSchedule(currentWeek),
  [store, currentWeek]);

  const phase1Sample = useMemo(() =>
    store.getWeekSchedule(1),
  [store]);

  const phase2Sample = useMemo(() =>
    store.getWeekSchedule(4),
  [store]);

  const displayDays = viewMode === 'week' ? weekSchedule
    : viewMode === 'phase1' ? phase1Sample
    : phase2Sample;

  return (
    <div className="space-y-5 p-4 md:p-6 anim-fade-scale">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">📅 Weekly Timetable</h1>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
            Mon–Sat study schedule with 3–4 hour gap between blocks
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {(['week', 'phase1', 'phase2'] as const).map(v => (
            <button key={v} onClick={() => setViewMode(v)}
              className={`nav-tab ${viewMode === v ? 'active' : ''}`}>
              {v === 'week' ? '📆 This Week' : v === 'phase1' ? '🌱 Phase 1 Sample' : '🚀 Phase 2 Sample'}
            </button>
          ))}
        </div>
      </div>

      {/* Week Navigator */}
      {viewMode === 'week' && (
        <div className="card-3d p-4 flex items-center justify-between">
          <button
            onClick={() => setCurrentWeek(w => Math.max(1, w - 1))}
            className="btn-3d btn-ghost px-4 py-2"
            disabled={currentWeek <= 1}
          >
            ← Prev
          </button>
          <div className="text-center">
            <div className="font-black text-white text-lg">Week {currentWeek}</div>
            <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              Phase {currentWeek <= 3 ? '1 — Rhythm Builder' : '2 — Final Execution'}
            </div>
            {weekSchedule[0] && (
              <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.3)' }}>
                {new Date(weekSchedule[0].date + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                {' – '}
                {new Date(weekSchedule[weekSchedule.length - 1].date + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
              </div>
            )}
          </div>
          <button
            onClick={() => setCurrentWeek(w => Math.min(24, w + 1))}
            className="btn-3d btn-ghost px-4 py-2"
            disabled={currentWeek >= 24}
          >
            Next →
          </button>
        </div>
      )}

      {/* Phase label */}
      {viewMode !== 'week' && (
        <div className="card-extruded px-4 py-3 flex items-center gap-3">
          <span className="text-xl">{viewMode === 'phase1' ? '🌱' : '🚀'}</span>
          <div>
            <div className="font-bold text-white text-sm">
              {viewMode === 'phase1' ? 'Phase 1: Rhythm Builder (Weeks 1–3)' : 'Phase 2: Final Execution (Weeks 4–24)'}
            </div>
            <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {viewMode === 'phase1'
                ? '1 lecture/session · 20-min revision start · Alternating Day A & B'
                : '2 lectures/session (Phy & Math) · 1 for Chem · Hybrid Fri/Sat with spaced recall'}
            </div>
          </div>
        </div>
      )}

      {/* Daily structure legend */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {[
          { icon: '⚡', color: '#00d4ff', title: 'Day A', desc: 'Physics (Block 1) + Chemistry (Block 2)', time: '6–8 AM | 12–2 PM' },
          { icon: '∑', color: '#6c63ff', title: 'Day B', desc: 'Math (Block 1) + English/Hindi (Block 2)', time: '6–8 AM | 12–12:45 PM' },
          { icon: '⏸️', color: '#ffb347', title: '3–4h Gap', desc: 'Screen-free recharge between blocks', time: 'Focus Mode: Tab A9' },
        ].map(item => (
          <div key={item.title} className="card-extruded px-4 py-3 flex items-center gap-3">
            <span className="text-xl" style={{ color: item.color }}>{item.icon}</span>
            <div>
              <div className="font-bold text-sm" style={{ color: item.color }}>{item.title}</div>
              <div className="text-xs text-white">{item.desc}</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.35)' }}>{item.time}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Days Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 stagger">
        {displayDays.map(day => (
          <div key={day.date} className="anim-fade-up">
            <DayCard day={day} store={store} />
          </div>
        ))}
      </div>

      {/* Jump to Today */}
      <div className="flex justify-center">
        <button
          onClick={() => {
            const today = new Date().toISOString().split('T')[0];
            const day = store.schedule.find(d => d.date === today);
            if (day) { setCurrentWeek(day.week); setViewMode('week'); }
          }}
          className="btn-3d btn-primary px-6 py-2.5"
        >
          📍 Jump to Today
        </button>
      </div>
    </div>
  );
}
