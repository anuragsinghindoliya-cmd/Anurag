import { useMemo } from 'react';
import { SUBJECTS, MONTHLY_TARGETS, PLAN_START_DATE } from '../data/plannerData';
import type { usePlannerStore } from '../store/plannerStore';

type Store = ReturnType<typeof usePlannerStore>;
interface Props { store: Store; }

function getDaysUntilDecember() {
  const target = new Date('2025-12-07');
  const now = new Date();
  const diff = Math.ceil((target.getTime() - now.getTime()) / 86400000);
  return Math.max(0, diff);
}

function getWeeksLeft() {
  const target = new Date('2025-12-07');
  const now = new Date();
  const diff = Math.ceil((target.getTime() - now.getTime()) / (86400000 * 7));
  return Math.max(0, diff);
}

export default function PacingGuide({ store }: Props) {
  const daysLeft = getDaysUntilDecember();
  const weeksLeft = getWeeksLeft();

  const overall = store.getOverallProgress();
  const lecturesToGo = overall.total - overall.done;
  const lecPerDay = daysLeft > 0 ? (lecturesToGo / (daysLeft * 5 / 7)).toFixed(1) : '0';

  const subjectPacing = useMemo(() => SUBJECTS.map(s => {
    const p = store.getSubjectProgress(s.key);
    const remaining = p.totalLectures - p.doneLectures;
    const chRemaining = p.totalChapters - p.doneChapters;
    const chPerWeek = weeksLeft > 0 ? (chRemaining / weeksLeft).toFixed(1) : '0';
    const lecPerWeek = weeksLeft > 0 ? (remaining / weeksLeft).toFixed(1) : '0';
    return { ...s, p, remaining, chRemaining, chPerWeek, lecPerWeek };
  }), [store, weeksLeft]);

  const isOnTrack = overall.pct >= Math.min(100, ((new Date().getTime() - PLAN_START_DATE.getTime()) / (new Date('2025-12-07').getTime() - PLAN_START_DATE.getTime())) * 100);

  return (
    <div className="space-y-5 p-4 md:p-6 anim-fade-scale">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">🗓️ Pacing & Deadline Guide</h1>
        <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
          Real-time countdown and chapter-by-chapter pacing to hit December 7, 2025
        </p>
      </div>

      {/* Countdown Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 stagger">
        {[
          { icon: '⏰', label: 'Days Left',       value: daysLeft,    color: daysLeft < 30 ? '#ff4d6d' : daysLeft < 60 ? '#ffb347' : '#00e5a0' },
          { icon: '📅', label: 'Weeks Left',      value: weeksLeft,   color: '#6c63ff' },
          { icon: '📚', label: 'Lectures Left',   value: lecturesToGo, color: '#00d4ff' },
          { icon: '📈', label: 'Lec/Study Day',   value: lecPerDay,   color: '#ffb347' },
        ].map((m, i) => (
          <div key={i} className="metric-widget anim-fade-up text-center">
            <div className="text-3xl mb-2">{m.icon}</div>
            <div className="text-3xl font-black" style={{ color: m.color }}>{m.value}</div>
            <div className="text-xs font-semibold text-white mt-1">{m.label}</div>
          </div>
        ))}
      </div>

      {/* On-Track Status */}
      <div className="card-3d p-5" style={{
        borderTop: `2px solid ${isOnTrack ? '#00e5a0' : '#ff4d6d'}`,
        boxShadow: `var(--shadow-lg), 0 -2px 20px ${isOnTrack ? 'rgba(0,229,160,0.15)' : 'rgba(255,77,109,0.15)'}`,
      }}>
        <div className="flex items-center gap-4">
          <span className="text-4xl">{isOnTrack ? '✅' : '⚠️'}</span>
          <div className="flex-1">
            <h3 className="font-black text-white text-lg">
              {isOnTrack ? "You're On Track! 🎯" : "Behind Schedule — Accelerate! 🚀"}
            </h3>
            <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.5)' }}>
              {isOnTrack
                ? `You've completed ${overall.pct}% of the syllabus. Keep the momentum going with your Phase ${overall.pct < 15 ? '1' : '2'} schedule.`
                : `You need to pick up the pace. Target ${lecPerDay} lectures per study day to finish by December 7.`}
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-black" style={{ color: isOnTrack ? '#00e5a0' : '#ff4d6d' }}>
              {overall.pct}%
            </div>
            <div className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>syllabus done</div>
          </div>
        </div>
      </div>

      {/* Subject Pacing Table */}
      <div className="card-3d p-5">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>
          📊 Per-Subject Pacing Required
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                {['Subject', 'Progress', 'Done', 'Remaining', 'Ch Left', 'Ch/Week', 'Lec/Week'].map(h => (
                  <th key={h} className="text-left pb-3 pr-4 font-bold text-xs uppercase tracking-wider"
                    style={{ color: 'rgba(255,255,255,0.35)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="space-y-2">
              {subjectPacing.map(s => (
                <tr key={s.key} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{s.icon}</span>
                      <span className="font-semibold text-white">{s.label}</span>
                    </div>
                  </td>
                  <td className="py-3 pr-4">
                    <div className="w-24">
                      <div className="progress-3d" style={{ height: 6 }}>
                        <div className="progress-fill" style={{
                          width: `${s.p.pct}%`,
                          background: `linear-gradient(90deg, ${s.color}80, ${s.color})`,
                        }} />
                      </div>
                      <div className="text-xs mt-0.5 font-bold" style={{ color: s.color }}>{s.p.pct}%</div>
                    </div>
                  </td>
                  <td className="py-3 pr-4 font-semibold" style={{ color: '#00e5a0' }}>
                    {s.p.doneLectures}/{s.p.totalLectures}
                  </td>
                  <td className="py-3 pr-4 font-bold" style={{ color: s.remaining > 0 ? s.color : '#00e5a0' }}>
                    {s.remaining} lec
                  </td>
                  <td className="py-3 pr-4" style={{ color: 'rgba(255,255,255,0.6)' }}>
                    {s.chRemaining} ch
                  </td>
                  <td className="py-3 pr-4">
                    <span className="badge-3d" style={{
                      color: parseFloat(s.chPerWeek) > 1.5 ? '#ff4d6d' : parseFloat(s.chPerWeek) > 0.8 ? '#ffb347' : '#00e5a0',
                      borderColor: parseFloat(s.chPerWeek) > 1.5 ? '#ff4d6d' : parseFloat(s.chPerWeek) > 0.8 ? '#ffb347' : '#00e5a0',
                    }}>
                      {s.chPerWeek}/wk
                    </span>
                  </td>
                  <td className="py-3">
                    <span className="badge-3d" style={{ color: s.color, borderColor: s.color }}>
                      {s.lecPerWeek}/wk
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monthly Targets Detail */}
      <div className="card-3d p-5">
        <h3 className="text-sm font-bold uppercase tracking-widest mb-5" style={{ color: 'rgba(255,255,255,0.4)' }}>
          📅 Month-by-Month Chapter Checklist
        </h3>
        <div className="space-y-4">
          {MONTHLY_TARGETS.map((m, i) => {
            const isCurrentMonth = i === Math.min(MONTHLY_TARGETS.length - 1, Math.floor(
              (new Date().getTime() - PLAN_START_DATE.getTime()) / (30 * 86400000)
            ));
            return (
              <div key={i} className="card-extruded p-4"
                style={isCurrentMonth ? {
                  borderColor: 'rgba(108,99,255,0.4)',
                  boxShadow: 'var(--shadow-md), 0 0 20px rgba(108,99,255,0.15)',
                } : {}}>
                <div className="flex items-start justify-between flex-wrap gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    {isCurrentMonth && <span className="text-yellow-400">▶</span>}
                    <h4 className="font-black text-white">{m.month}</h4>
                    {isCurrentMonth && (
                      <span className="badge-3d" style={{ color: '#6c63ff', borderColor: '#6c63ff', fontSize: '0.6rem' }}>
                        CURRENT
                      </span>
                    )}
                  </div>
                  <span className="badge-3d" style={{
                    color: m.phase === 'FINAL' ? '#ffb347' : m.phase === '1' ? '#00e5a0' : '#6c63ff',
                    borderColor: m.phase === 'FINAL' ? '#ffb347' : m.phase === '1' ? '#00e5a0' : '#6c63ff',
                  }}>
                    Phase {m.phase}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 mb-3">
                  {[
                    { label: '⚡ Physics', val: m.physicsChapters, color: '#00d4ff' },
                    { label: '🧪 Chemistry', val: m.chemistryChapters, color: '#00e5a0' },
                    { label: '∑ Math', val: m.mathChapters, color: '#6c63ff' },
                  ].map(x => (
                    <div key={x.label} className="text-center rounded-xl p-3"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}>
                      <div className="text-2xl font-black" style={{ color: x.color }}>{x.val}</div>
                      <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>{x.label}</div>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.25)' }}>chapters</div>
                    </div>
                  ))}
                </div>

                <div className="text-sm p-3 rounded-xl" style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.05)',
                  color: 'rgba(255,255,255,0.5)',
                }}>
                  {m.note}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Phase Rules Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Phase 1 Rules */}
        <div className="card-3d p-5">
          <h3 className="font-bold text-white mb-3 flex items-center gap-2">
            <span>🌱</span> Phase 1 Daily Rules (Weeks 1–3)
          </h3>
          <div className="space-y-2">
            {[
              { icon: '⏰', text: 'Block 1: 6:00 AM – 8:00 AM' },
              { icon: '☀️', text: '3–4 hour gap (screen-free recharge)' },
              { icon: '📚', text: 'Block 2: 12:00 PM onward' },
              { icon: '📝', text: '1 lecture per primary subject session' },
              { icon: '🔄', text: 'First 20 min = Revise previous lecture' },
              { icon: '🔀', text: 'Alternate Day A (Phy+Chem) ↔ Day B (Math+Lang)' },
              { icon: '💬', text: 'Language blocks: 45 minutes only' },
              { icon: '📵', text: 'Tab A9 Focus Mode: ALL study blocks' },
              { icon: '🌟', text: 'Sunday = Zero study, full recharge' },
            ].map((r, i) => (
              <div key={i} className="flex gap-2 text-sm">
                <span>{r.icon}</span>
                <span style={{ color: 'rgba(255,255,255,0.6)' }}>{r.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Phase 2 Rules */}
        <div className="card-3d p-5">
          <h3 className="font-bold text-white mb-3 flex items-center gap-2">
            <span>🚀</span> Phase 2 Daily Rules (Weeks 4–24)
          </h3>
          <div className="space-y-2">
            {[
              { icon: '⚡', text: 'Physics: 2 lectures per Block 1' },
              { icon: '∑', text: 'Math: 2 lectures per Block 1' },
              { icon: '🧪', text: 'Chemistry: 1 lecture per Block 2' },
              { icon: '⏱️', text: 'Mon–Thu: 15-20 min review at block start' },
              { icon: '📅', text: 'Friday (Hybrid): 1 new lec + Spaced Recall (Phy/Chem)' },
              { icon: '🗓️', text: 'Saturday (Hybrid): 1 new lec + Blank-Sheet (Math/Lang)' },
              { icon: '✍️', text: 'Blank-Sheet: Write formulas before opening books' },
              { icon: '🧠', text: '3-Stage Revision: Initial + 2 Spaced Recalls' },
              { icon: '📵', text: 'Tab A9 Focus Mode: ALL study blocks' },
            ].map((r, i) => (
              <div key={i} className="flex gap-2 text-sm">
                <span>{r.icon}</span>
                <span style={{ color: 'rgba(255,255,255,0.6)' }}>{r.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
